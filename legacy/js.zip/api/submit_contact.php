<?php
require_once '../includes/config.php';
require_once '../includes/EmailService.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        header("Location: ../index.php?contact_status=error#contact");
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO contact_requests (name, email, subject, message) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $email, $subject, $message])) {
            // Notify user via email
            $to = "emmco96@gmail.com";
            $emailSubject = "New Portfolio Message: $subject";
            $emailBody = "You have received a new message from your portfolio contact form.\n\n" .
                         "Name: $name\n" .
                         "Email: $email\n\n" .
                         "Message:\n$message";
            
            EmailService::send($to, $emailSubject, $emailBody);

            header("Location: ../index.php?contact_status=success#contact");
            exit;
        }
    } catch (PDOException $e) {
        header("Location: ../index.php?contact_status=error#contact");
        exit;
    }
} else {
    header("Location: ../index.php");
    exit;
}
?>
