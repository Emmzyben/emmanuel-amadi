<?php
/**
 * Emmanuel Amadi Portfolio Helper Functions
 */

/**
 * Get all categories
 */
function get_categories($pdo) {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
    return $stmt->fetchAll();
}

/**
 * Get projects with their category name (optional limit)
 */
function get_projects($pdo, $limit = null) {
    $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug 
            FROM projects p 
            JOIN categories c ON p.category_id = c.id 
            ORDER BY p.created_at DESC";
    
    if ($limit !== null) {
        $sql .= " LIMIT " . (int)$limit;
    }
    
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll();
}

/**
 * Get all reviews
 */
function get_reviews($pdo) {
    $stmt = $pdo->query("SELECT * FROM reviews ORDER BY created_at DESC");
    return $stmt->fetchAll();
}
?>
