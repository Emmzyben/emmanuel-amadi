<?php
require_once '../includes/config.php';
require_once 'auth_check.php';

$message = "";

// Handle Add Project
if (isset($_POST['add_project'])) {
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $link = $_POST['link'];
    
    // Image Upload
    $image = $_FILES['image'];
    $image_name = time() . '_' . basename($image['name']);
    $target_file = UPLOAD_DIR . $image_name;
    
    if (move_uploaded_file($image['tmp_name'], $target_file)) {
        $stmt = $pdo->prepare("INSERT INTO projects (name, category_id, link, image) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $category_id, $link, $image_name])) {
            $message = "Project added successfully!";
        }
    } else {
        $message = "Failed to upload image.";
    }
}

// Handle Delete Project
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Delete file first
    $stmt = $pdo->prepare("SELECT image FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch();
    if ($project) {
        @unlink(UPLOAD_DIR . $project['image']);
        $pdo->prepare("DELETE FROM projects WHERE id = ?")->execute([$id]);
        $message = "Project deleted successfully!";
    }
}

// Fetch data
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
$projects = $pdo->query("SELECT p.*, c.name as category_name FROM projects p JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Portfolio - Amadi Admin</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar">
                <div class="sidebar-header">
                    <h3>AMADI ADMIN</h3>
                </div>
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-home"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_categories.php">
                                <i class="fas fa-list"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="manage_portfolio.php">
                                <i class="fas fa-briefcase"></i> Portfolio
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_reviews.php">
                                <i class="fas fa-star"></i> Reviews
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_requests.php">
                                <i class="fas fa-envelope"></i> Requests
                            </a>
                        </li>
                        <li class="nav-item mt-5">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-10 ml-sm-auto main-content">
                <div class="page-header">
                    <h2>Manage Portfolio</h2>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div class="card">
                            <div class="card-header">Add New Project</div>
                            <div class="card-body">
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Project Name</label>
                                                <input type="text" name="name" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Category</label>
                                                <select name="category_id" class="form-control" required>
                                                    <option value="">Select Category</option>
                                                    <?php foreach ($categories as $cat): ?>
                                                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Project Link</label>
                                                <input type="url" name="link" class="form-control" placeholder="https://...">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Project Image</label>
                                                <input type="file" name="image" class="form-control" required accept="image/*">
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" name="add_project" class="btn btn-primary">Publish Project</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">Published Projects</div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>Link</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($projects as $proj): ?>
                                                <tr>
                                                    <td><img src="../uploads/<?php echo $proj['image']; ?>" width="60" height="40" style="object-fit: cover; border: 1px solid #FF6F61;"></td>
                                                    <td><?php echo htmlspecialchars($proj['name']); ?></td>
                                                    <td><span class="badge badge-secondary"><?php echo htmlspecialchars($proj['category_name']); ?></span></td>
                                                    <td><small><?php echo htmlspecialchars($proj['link']); ?></small></td>
                                                    <td>
                                                        <a href="?delete=<?php echo $proj['id']; ?>" class="text-danger" onclick="return confirm('Delete this project?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                            <?php if (empty($projects)): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">No projects in portfolio.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
