<?php
require_once '../includes/config.php';
require_once 'auth_check.php';

$message = "";

// Handle Add Review
if (isset($_POST['add_review'])) {
    $name = $_POST['reviewer_name'];
    $location = $_POST['location'];
    $review_text = $_POST['review_text'];
    
    // Image Upload
    $image = $_FILES['image'];
    $image_name = time() . '_' . basename($image['name']);
    $target_file = UPLOAD_DIR . $image_name;
    
    if (move_uploaded_file($image['tmp_name'], $target_file)) {
        $stmt = $pdo->prepare("INSERT INTO reviews (reviewer_name, location, review_text, image) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $location, $review_text, $image_name])) {
            $message = "Review added successfully!";
        }
    } else {
        $message = "Failed to upload image.";
    }
}

// Handle Delete Review
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("SELECT image FROM reviews WHERE id = ?");
    $stmt->execute([$id]);
    $review = $stmt->fetch();
    if ($review) {
        @unlink(UPLOAD_DIR . $review['image']);
        $pdo->prepare("DELETE FROM reviews WHERE id = ?")->execute([$id]);
        $message = "Review deleted successfully!";
    }
}

// Fetch reviews
$reviews = $pdo->query("SELECT * FROM reviews ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reviews - Amadi Admin</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar">
                <div class="sidebar-header">
                    <h3>AMADI ADMIN</h3>
                </div>
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-home"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_categories.php">
                                <i class="fas fa-list"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_portfolio.php">
                                <i class="fas fa-briefcase"></i> Portfolio
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="manage_reviews.php">
                                <i class="fas fa-star"></i> Reviews
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_requests.php">
                                <i class="fas fa-envelope"></i> Requests
                            </a>
                        </li>
                        <li class="nav-item mt-5">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-10 ml-sm-auto main-content">
                <div class="page-header">
                    <h2>Manage Reviews</h2>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div class="card">
                            <div class="card-header">Add New Review</div>
                            <div class="card-body">
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Reviewer Name</label>
                                                <input type="text" name="reviewer_name" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Location / Profession</label>
                                                <input type="text" name="location" class="form-control" required placeholder="e.g. Lagos, Nigeria or CEO, Tech Co">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Review Text</label>
                                                <textarea name="review_text" class="form-control" rows="3" required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Reviewer Photo</label>
                                                <input type="file" name="image" class="form-control" required accept="image/*">
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" name="add_review" class="btn btn-primary">Save Review</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">Existing Reviews</div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Photo</th>
                                                <th>Name</th>
                                                <th>Location</th>
                                                <th>Review</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($reviews as $rev): ?>
                                                <tr>
                                                    <td><img src="../uploads/<?php echo $rev['image']; ?>" width="50" height="50" style="object-fit: cover; border-radius: 50%; border: 1px solid #FF6F61;"></td>
                                                    <td><?php echo htmlspecialchars($rev['reviewer_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($rev['location']); ?></td>
                                                    <td><small><?php echo substr(htmlspecialchars($rev['review_text']), 0, 50); ?>...</small></td>
                                                    <td>
                                                        <a href="?delete=<?php echo $rev['id']; ?>" class="text-danger" onclick="return confirm('Delete this review?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                            <?php if (empty($reviews)): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">No reviews found.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
